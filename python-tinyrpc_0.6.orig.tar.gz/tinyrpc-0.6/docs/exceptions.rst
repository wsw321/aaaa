Exception reference
-------------------

.. automodule:: tinyrpc.exc
   :members:
